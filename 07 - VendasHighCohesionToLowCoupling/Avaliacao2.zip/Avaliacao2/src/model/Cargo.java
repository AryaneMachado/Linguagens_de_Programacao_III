package model;

public interface Cargo {
	
	String descricao();
	Double calculaSalario(Double qtdHora);

}
