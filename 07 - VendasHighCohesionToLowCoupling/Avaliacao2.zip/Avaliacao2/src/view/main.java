package view;

import model.Analista;
import model.Arquiteto;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Analista a1 = new Analista();
	Arquiteto ar1 = new Arquiteto();
	ar1.calculaSalarioAquiteto(2.0, 3);
	

	}

}
