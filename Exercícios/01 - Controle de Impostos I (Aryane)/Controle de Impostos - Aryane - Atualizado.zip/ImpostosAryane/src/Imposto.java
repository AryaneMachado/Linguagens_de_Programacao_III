
class Imposto {
    String nome;
    double taxa;

    Imposto(String nome, double taxa) {
        this.nome = nome;
        this.taxa = taxa;
    }
}
