import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
	
    public static void main(String[] args) {
    	
        Scanner scanner = new Scanner(System.in);
        List<Produto> produtos = new ArrayList<>();

        while (true) {
            System.out.print("Digite o nome do produto (ou '0' para mostrar Relatório): ");
            String nome = scanner.nextLine();
            
            if (nome.equalsIgnoreCase("0")) {
                break;
            }

            System.out.print("Digite o valor de custo do produto: ");
            double valorCusto = Double.parseDouble(scanner.nextLine());

            System.out.print("Digite a margem de lucro do produto (em decimal): ");
            double margemLucro = Double.parseDouble(scanner.nextLine());

            System.out.print("Digite a categoria do produto:\n"
                    + "1 - Arroz\n"
                    + "2 - Feijão\n"
                    + "3 - Carne\n"
                    + "4 - Cerveja\n"
                    + "5 - Gás\n"
                    + "6 - Gasolina");
            		         
            int categoria = Integer.parseInt(scanner.nextLine());

            Produto produto = new Produto(nome, valorCusto, margemLucro, categoria);
            produtos.add(produto);
        }
        
        

        System.out.println("\nRELATÓRIO DE PRODUTOS CADASTRADOS:\n");
        
        
        for (Produto produto : produtos) {
            System.out.println("- Nome: " + produto.getNome());
            System.out.println("- Categoria: " + produto.categoria);
            System.out.println("- Preço de Custo: R$" + produto.valorCusto);
            
            System.out.println("\n- Impostos Incididos:\n");
            for (Imposto imposto : produto.impostos) {
                double valorImposto = produto.valorCusto * imposto.taxa;
                System.out.println(imposto.nome + ": R$" + valorImposto + " (" + (imposto.taxa * 100.2f) + "%)");
            }
            
            System.out.println("\n- Valor Final: R$" + produto.valorFinal);
            System.out.println("\n______________________________________\n");
        }
        
        
    
}

}