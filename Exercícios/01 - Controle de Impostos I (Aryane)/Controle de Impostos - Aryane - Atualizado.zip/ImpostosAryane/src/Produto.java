import java.util.ArrayList;
import java.util.List;

    class Produto {
    private String nome;

	double valorCusto;
    double margemLucro;
    int categoria;
    double valorFinal;
    
    List<Imposto> impostos = new ArrayList<>();
    
    // Construtor:
    
    Produto(String nome, double valorCusto, double margemLucro, int categoria) {
        this.setNome(nome);
        this.valorCusto = valorCusto;
        this.margemLucro = margemLucro;
        this.categoria = categoria;
        this.calcularValorFinal();
    }
    
    
    public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public double getValorCusto() {
		return valorCusto;
	}


	public void setValorCusto(double valorCusto) {
		this.valorCusto = valorCusto;
	}


	public double getMargemLucro() {
		return margemLucro;
	}


	public void setMargemLucro(double margemLucro) {
		this.margemLucro = margemLucro;
	}


	public int getCategoria() {
		return categoria;
	}


	public void setCategoria(int categoria) {
		this.categoria = categoria;
	}


	public double getValorFinal() {
		return valorFinal;
	}


	public void setValorFinal(double valorFinal) {
		this.valorFinal = valorFinal;
	}


	public List<Imposto> getImpostos() {
		return impostos;
	}  
   
	//-------------------------------------------------------------------------------------------

    	public void calcularValorFinal() { // Calculando os impostos incididos no preço de custo
    	
        if (categoria == 1 || categoria == 2) { // arroz e feijão
        	impostos.add(new Imposto("Confins",0.12));
            impostos.add(new Imposto("ICMS", 0.07));
            impostos.add(new Imposto("ISS", 0.05));
            
        } else if (categoria == 3) { // carne
        	
        	impostos.add(new Imposto("Confins",0.12));
            impostos.add(new Imposto("ICMS", 0.07));
            impostos.add(new Imposto("IPI", 0.08));
            
        }else if (categoria == 4) { // cerveja
        	impostos.add(new Imposto("Confins",0.12));
            impostos.add(new Imposto("ICMS", 0.07));
            impostos.add(new Imposto("ISS", 0.05));
            impostos.add(new Imposto("IPI", 0.08));   
            
        } else if (categoria == 5) { // gas
        	
        	impostos.add(new Imposto("Confins",0.12));
            impostos.add(new Imposto("ICMS", 0.07));
            impostos.add(new Imposto("IPI", 0.08));
        	
        } else if (categoria == 6) { // gasolina
        	impostos.add(new Imposto("Confins",0.12));
            impostos.add(new Imposto("ICMS", 0.07));
            impostos.add(new Imposto("Cide", 0.10));
        	
        }
        
        else {
        	System.out.println("Categoria de produtos não cadastrada!");
        }
        
        //-------------------------------------------------------------------------
        

        double valorImpostos = 0;
        for (Imposto imposto : impostos) {
            valorImpostos += valorCusto * imposto.taxa;
        }

        double valorLucro = valorCusto * margemLucro;
        valorFinal = valorCusto + valorImpostos + valorLucro;
    }

	
}
